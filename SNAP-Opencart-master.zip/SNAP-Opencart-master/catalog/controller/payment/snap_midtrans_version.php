<?php
// Version
define('OC2_MIDTRANS_PLUGIN_VERSION', '2.0.1');