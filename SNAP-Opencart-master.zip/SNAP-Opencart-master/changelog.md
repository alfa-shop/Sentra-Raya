# Changelog

2.0.1
-----
- add disable midtrans mixpanel on admin settings
- change cc bin payment method to specific payment method
- add enabled_payments on specific payment method
- add custom_expiry on specific payment method
- reconfig snap.js onSuccess callback

2.0.0
-----
- bump version to 2.0.0

1.3
------
- compatible with opencart 2.1

1.1.0
-----
- add several payment method
- add finish, unfinish, error url